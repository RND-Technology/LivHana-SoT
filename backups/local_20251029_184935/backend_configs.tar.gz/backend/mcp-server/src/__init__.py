"""Liv Hana TRUTH Pipeline MCP Server for ChatGPT Apps SDK."""

__version__ = "1.0.0"
